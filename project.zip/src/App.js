
import {Routes} from "react-router-dom";
import Home from "./components/Home";

function App() {
  return (
    <Home />
  );
}

export default App;
